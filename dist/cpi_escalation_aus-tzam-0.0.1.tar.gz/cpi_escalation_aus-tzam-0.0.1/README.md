# cpi_escalation_aus
Class to escalate and deescalate Australian dollar values based on ABS CPI index
